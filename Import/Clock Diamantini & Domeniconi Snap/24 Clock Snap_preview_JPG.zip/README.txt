Thank you for purchasing model+model products.

1. INTRODUCTION

Model+model creates for you 3d models of high quality. Now you can easily add more details to your scenes and greatly save your time. Model+model also gives you the opportunity to choose whether to buy a single model or purchase a large number of models in one volume at a very attractive price. All our models available in different formats with all textures. 

2. HOW TO USE

We were working very hard to make all products simple to use. The name of any file contains the volume number, the product number and some description. For example mpm_vol.01_p06_vray.MAX means the product number 6  from volume 1 prepared for use in *.max scenes with vray rendering system. To quickly find any product we named all folders with the real names of the objects. These names you can also find in the pdf-catalogue of the volume. 
Some models are provided in different materials. All available variations are showed in jpg-previews, in pdf-catalogue of the volume and in the site modelplusmodel.com. To get a model with another material do the following: select this model, choose the material you want from the material library or *.mat file and assign it. Note that materials available only for 3dsmax scenes with scanline or vray rendering system.

3. LICENSE AGREEMENT

All digital products are the property of model+model and protected by intellectual property laws. 
Any digital product or files that accompany it, such as textures or images cannot be resold, assigned, published or otherwise redistributed. Any product can be used for private or commercial use only by customers who bought it. The buyers may modify models or textures in any way in order to conform them to their needs. However, any such modifications are still derivatives of the original and cannot be sold or distributed as your own.


4. CONTACT US

We very much appreciate your opinion on model+model products and are always waiting for your ideas about future products. Please send any feedback to info@modelplusmodel.com or use the contact form on our site. Thank you.

model+model
www.modelplusmodel.com